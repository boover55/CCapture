// content.js is injected fresh on every capture via executeScript.
// The listener is guarded so it only registers once per page lifetime,
// but the activation state is always reset on re-injection so a second
// (or third, etc.) capture always gets a clean slate.

// ── Register message listener exactly once ────────────────────
// The listener survives service-worker restarts because it lives in the
// content-script context, not the worker. Using window flags lets us
// detect re-injection without losing the handler.
if (!window.__ccapture_listener_registered) {
  window.__ccapture_listener_registered = true;
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "ACTIVATE_SELECTION") {
      window.__ccapture_activate?.();
    }
  });
}

// ── Reset any state left over from a previous capture ─────────
window.__ccapture_teardown?.();

// ── Fresh selection state (IIFE so let/const are re-declarable) ──
(function () {
  let overlay = null;
  let selBox  = null;
  let label   = null;
  let startX  = 0, startY = 0;
  let isDrawing = false;

  function activate() {
    if (overlay) return;

    // Full-screen dimming overlay (dims the page before the user starts drawing)
    overlay = document.createElement("div");
    overlay.style.cssText = `
      position: fixed;
      inset: 0;
      z-index: 2147483646;
      cursor: crosshair;
      user-select: none;
      background: rgba(0,0,0,0.45);
    `;

    // Selection rectangle — box-shadow dims outside the selection
    selBox = document.createElement("div");
    selBox.style.cssText = `
      position: fixed;
      border: 2px solid #1a73e8;
      background: transparent;
      box-shadow: 0 0 0 9999px rgba(0,0,0,0.45);
      display: none;
      pointer-events: none;
      z-index: 2147483647;
    `;

    // Instruction label
    label = document.createElement("div");
    label.textContent = "Drag to select  ·  Esc to cancel";
    label.style.cssText = `
      position: fixed;
      top: 14px;
      left: 50%;
      transform: translateX(-50%);
      background: rgba(15,15,25,0.88);
      color: #e8eaed;
      font: 13px/1.5 system-ui, sans-serif;
      padding: 6px 16px;
      border-radius: 6px;
      pointer-events: none;
      z-index: 2147483648;
      white-space: nowrap;
      letter-spacing: 0.01em;
    `;

    document.body.appendChild(overlay);
    document.body.appendChild(selBox);
    document.body.appendChild(label);

    overlay.addEventListener("mousedown", onMouseDown);
    document.addEventListener("keydown", onKeyDown, true);
  }

  function onMouseDown(e) {
    if (e.button !== 0) return;
    e.preventDefault();
    isDrawing = true;
    startX = e.clientX;
    startY = e.clientY;

    // Remove overlay background so only selBox box-shadow dims outside
    overlay.style.background = "transparent";
    selBox.style.display = "block";
    updateSelBox(e.clientX, e.clientY);

    overlay.addEventListener("mousemove", onMouseMove);
    overlay.addEventListener("mouseup",   onMouseUp);
  }

  function onMouseMove(e) {
    if (!isDrawing) return;
    updateSelBox(e.clientX, e.clientY);
  }

  function updateSelBox(cx, cy) {
    const x = Math.min(cx, startX);
    const y = Math.min(cy, startY);
    const w = Math.abs(cx - startX);
    const h = Math.abs(cy - startY);
    selBox.style.left   = x + "px";
    selBox.style.top    = y + "px";
    selBox.style.width  = w + "px";
    selBox.style.height = h + "px";
  }

  function onMouseUp(e) {
    if (!isDrawing) return;
    isDrawing = false;

    const x = Math.min(e.clientX, startX);
    const y = Math.min(e.clientY, startY);
    const w = Math.abs(e.clientX - startX);
    const h = Math.abs(e.clientY - startY);

    teardown();

    if (w < 5 || h < 5) {
      chrome.runtime.sendMessage({ type: "CAPTURE_CANCELLED" });
      return;
    }

    chrome.runtime.sendMessage({
      type: "SELECTION_COMPLETE",
      rect: { x, y, width: w, height: h, dpr: window.devicePixelRatio || 1 },
    });
  }

  function onKeyDown(e) {
    if (e.key === "Escape") {
      teardown();
      chrome.runtime.sendMessage({ type: "CAPTURE_CANCELLED" });
    }
  }

  function teardown() {
    isDrawing = false;
    overlay?.removeEventListener("mousemove", onMouseMove);
    overlay?.removeEventListener("mouseup",   onMouseUp);
    document.removeEventListener("keydown", onKeyDown, true);
    overlay?.remove();
    selBox?.remove();
    label?.remove();
    overlay = null;
    selBox  = null;
    label   = null;
    // Clear global refs so a re-injection knows there's nothing to clean up
    window.__ccapture_activate = null;
    window.__ccapture_teardown = null;
  }

  // Expose to the outer scope so re-injection can reset cleanly
  window.__ccapture_activate = activate;
  window.__ccapture_teardown = teardown;
}());
