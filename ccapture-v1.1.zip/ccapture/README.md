# CCapture

A Chrome extension for capturing screen regions and saving them as PNG images or multi-page PDFs — directly to a local folder, no upload required.

---

## Installation

CCapture is distributed as a folder (unpacked extension). Chrome can load it directly without the Web Store.

1. Unzip the archive (if you received a `.zip` file).
2. Open Chrome and navigate to `chrome://extensions`.
3. Enable **Developer mode** using the toggle in the top-right corner.
4. Click **Load unpacked** and select the `ccapture` folder.
5. The CCapture icon will appear in your toolbar. Pin it for easy access.

> After any update, return to `chrome://extensions` and click the **↺ Reload** button next to CCapture.

---

## Opening the panel

Click the CCapture icon in the toolbar. This opens a side panel that stays visible while you browse.

---

## Usage

### Single capture

1. Click **Choose** and select a folder where captures will be saved.
2. Click **Capture Area** (or press `Ctrl+E`).
3. Your screen dims. Drag a rectangle over the area you want to capture.
4. Review the preview in the panel, then click **Save** (or `Ctrl+S`) to write the PNG, or **Discard** (`Ctrl+D`) to discard it.

### PDF from multiple captures

1. Switch to the **PDF** tab in the panel header.
2. Enter a filename in the PDF name field.
3. Click **Add Capture** (or `Ctrl+E`) to capture a region and add it to the queue.
4. Repeat for each page you want in the PDF.
5. Reorder or remove pages in the queue using the ↑ ↓ × buttons.
6. Click **Create PDF** (`Ctrl+P` when panel is focused) to write the PDF to your chosen folder.

---

## Keyboard shortcuts

All four shortcuts work globally via Chrome's command API — even when a webpage has keyboard focus. They use `Ctrl+Shift` to avoid conflicting with Chrome's native `Ctrl`-only shortcuts (address bar, bookmark, quit, etc.).

| Shortcut | Action |
|---|---|
| `Ctrl+Shift+E` | Capture area |
| `Ctrl+Shift+S` | Save capture |
| `Ctrl+Shift+F` | Add capture to PDF queue |
| `Ctrl+Shift+X` | Discard preview |

You can reassign any of these at `chrome://extensions/shortcuts`.

---

## Tips

- Captures are kept in the session history (bottom of the Single tab) and can be re-previewed by clicking them.
- The save folder is remembered across sessions. You only need to pick it once.
- Pressing `Esc` during a drag cancels the capture without leaving the extension in a broken state.
