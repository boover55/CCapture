// ── Keyboard commands (registered in manifest.json) ──────────
// chrome.commands fires at the browser level — no focus or content-script
// injection issues. We relay to the sidepanel via chrome.storage.session
// because storage.onChanged is the most reliable cross-context bus.
const COMMAND_KEY = {
  "capture":      "e",   // Ctrl+Shift+E
  "save-capture": "s",   // Ctrl+Shift+S
  "add-to-pdf":   "f",   // Ctrl+Shift+F
  "discard":      "x",   // Ctrl+Shift+X
};

chrome.commands.onCommand.addListener((command) => {
  const key = COMMAND_KEY[command];
  if (key) chrome.storage.session.set({ __ccapture_shortcut: { key, ts: Date.now() } });
});

// Open side panel when extension icon is clicked
chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ tabId: tab.id });
});

// Message router
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "START_CAPTURE") {
    handleStartCapture(msg.tabId, sendResponse);
    return true; // async
  }
  if (msg.type === "SELECTION_COMPLETE") {
    handleSelectionComplete(sender.tab, msg.rect);
    sendResponse({ ok: true });
  }
  if (msg.type === "CAPTURE_CANCELLED") {
    // Broadcast to side panel
    chrome.runtime.sendMessage({ type: "CAPTURE_CANCELLED" }).catch(() => {});
  }

});

async function handleStartCapture(tabId, sendResponse) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["content.js"],
    });
    await chrome.tabs.sendMessage(tabId, { type: "ACTIVATE_SELECTION" });
    sendResponse({ ok: true });
  } catch (err) {
    sendResponse({ ok: false, error: err.message });
  }
}

async function handleSelectionComplete(tab, rect) {
  try {
    const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {
      format: "png",
    });
    const cropped = await cropImage(dataUrl, rect);
    // Send cropped image to the side panel
    chrome.runtime.sendMessage({ type: "CAPTURE_READY", dataUrl: cropped }).catch(() => {});
  } catch (err) {
    chrome.runtime.sendMessage({ type: "CAPTURE_ERROR", error: err.message }).catch(() => {});
  }
}

// Crop using OffscreenCanvas (available in Chrome 116+ service workers)
async function cropImage(dataUrl, rect) {
  const res = await fetch(dataUrl);
  const blob = await res.blob();
  const bitmap = await createImageBitmap(blob);

  const dpr = rect.dpr || 1;
  const sx = Math.round(rect.x * dpr);
  const sy = Math.round(rect.y * dpr);
  const sw = Math.round(rect.width * dpr);
  const sh = Math.round(rect.height * dpr);

  const csx = Math.max(0, Math.min(sx, bitmap.width));
  const csy = Math.max(0, Math.min(sy, bitmap.height));
  const csw = Math.max(1, Math.min(sw, bitmap.width - csx));
  const csh = Math.max(1, Math.min(sh, bitmap.height - csy));

  const canvas = new OffscreenCanvas(csw, csh);
  const ctx = canvas.getContext("2d");
  ctx.drawImage(bitmap, csx, csy, csw, csh, 0, 0, csw, csh);

  const outBlob = await canvas.convertToBlob({ type: "image/png" });
  return blobToDataUrl(outBlob);
}

function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}
