// ── Pure-JS PDF builder ──────────────────────────────────────
// Generates a PDF where each image gets its own page.
// Images are embedded as JPEG (DCTDecode) for broad compatibility.
// Returns a Uint8Array of the PDF bytes.

async function buildPdfFromDataUrls(dataUrls) {
  const images = await Promise.all(dataUrls.map(toJpegInfo));
  return assemblePdf(images);
}

// Convert any dataUrl to a JPEG Uint8Array + dimensions
function toJpegInfo(dataUrl) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onerror = reject;
    img.onload = () => {
      const w = img.naturalWidth;
      const h = img.naturalHeight;
      const canvas = document.createElement("canvas");
      canvas.width  = w;
      canvas.height = h;
      const ctx = canvas.getContext("2d");
      // White background for any transparent areas
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, w, h);
      ctx.drawImage(img, 0, 0);
      const jpegUrl = canvas.toDataURL("image/jpeg", 0.95);
      const b64 = jpegUrl.split(",")[1];
      const raw = atob(b64);
      const bytes = new Uint8Array(raw.length);
      for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
      resolve({ bytes, width: w, height: h });
    };
    img.src = dataUrl;
  });
}

// ── PDF binary assembly ──────────────────────────────────────
function assemblePdf(images) {
  const enc = new TextEncoder();
  const parts = [];     // Uint8Array chunks
  let pos = 0;          // current byte offset
  const offsets = {};   // object id → byte offset

  function w(str) {
    const b = enc.encode(str);
    parts.push(b);
    pos += b.length;
  }

  function wb(bytes) {
    parts.push(bytes);
    pos += bytes.length;
  }

  function mark(id) { offsets[id] = pos; }

  // Object numbering:
  //  1           → Catalog
  //  2           → Pages
  //  3 + i*3 + 0 → Page i
  //  3 + i*3 + 1 → Content stream i
  //  3 + i*3 + 2 → Image XObject i
  const N = images.length;
  const pageIds    = images.map((_, i) => 3 + i * 3);
  const contentIds = images.map((_, i) => 3 + i * 3 + 1);
  const imageIds   = images.map((_, i) => 3 + i * 3 + 2);
  const totalObjs  = 2 + N * 3;

  // PDF header — high-byte comment marks file as binary
  w("%PDF-1.4\n%\xFF\xFF\xFF\xFF\n");

  // 1: Catalog
  mark(1);
  w(`1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n`);

  // 2: Pages
  mark(2);
  const kids = pageIds.map(id => `${id} 0 R`).join(" ");
  w(`2 0 obj\n<< /Type /Pages /Kids [${kids}] /Count ${N} >>\nendobj\n`);

  // Per-image objects
  for (let i = 0; i < N; i++) {
    const { bytes: jpegBytes, width: W, height: H } = images[i];
    const pageId    = pageIds[i];
    const contentId = contentIds[i];
    const imageId   = imageIds[i];
    const imgName   = `Im${i + 1}`;

    // Page
    mark(pageId);
    w(
      `${pageId} 0 obj\n` +
      `<< /Type /Page /Parent 2 0 R\n` +
      `   /MediaBox [0 0 ${W} ${H}]\n` +
      `   /Contents ${contentId} 0 R\n` +
      `   /Resources << /XObject << /${imgName} ${imageId} 0 R >> >> >>\n` +
      `endobj\n`
    );

    // Content stream: scale-to-page and draw image
    const stream = `q ${W} 0 0 ${H} 0 0 cm /${imgName} Do Q\n`;
    mark(contentId);
    w(
      `${contentId} 0 obj\n` +
      `<< /Length ${stream.length} >>\n` +
      `stream\n` +
      stream +
      `endstream\nendobj\n`
    );

    // Image XObject (JPEG)
    mark(imageId);
    w(
      `${imageId} 0 obj\n` +
      `<< /Type /XObject /Subtype /Image\n` +
      `   /Width ${W} /Height ${H}\n` +
      `   /ColorSpace /DeviceRGB /BitsPerComponent 8\n` +
      `   /Filter /DCTDecode /Length ${jpegBytes.length} >>\n` +
      `stream\n`
    );
    wb(jpegBytes);
    w(`\nendstream\nendobj\n`);
  }

  // Cross-reference table
  const xrefPos = pos;
  w(`xref\n0 ${totalObjs + 1}\n`);
  w(`0000000000 65535 f\r\n`); // free entry 0
  for (let id = 1; id <= totalObjs; id++) {
    w(String(offsets[id]).padStart(10, "0") + ` 00000 n\r\n`);
  }

  // Trailer
  w(`trailer\n<< /Size ${totalObjs + 1} /Root 1 0 R >>\nstartxref\n${xrefPos}\n%%EOF\n`);

  // Concatenate all parts into one Uint8Array
  const total = parts.reduce((s, p) => s + p.length, 0);
  const out = new Uint8Array(total);
  let cursor = 0;
  for (const p of parts) { out.set(p, cursor); cursor += p.length; }
  return out;
}
