// ── DOM refs ─────────────────────────────────────────────────
const chooseFolderBtn   = document.getElementById("chooseFolderBtn");
const folderPath        = document.getElementById("folderPath");

// Mode tabs
const modeTabs          = document.querySelectorAll(".mode-tab");
const singleModeEl      = document.getElementById("singleMode");
const pdfModeEl         = document.getElementById("pdfMode");

// Single mode
const captureBtn        = document.getElementById("captureBtn");
const statusHint        = document.getElementById("statusHint");
const previewSection    = document.getElementById("previewSection");
const previewImg        = document.getElementById("previewImg");
const previewMeta       = document.getElementById("previewMeta");
const saveBtn           = document.getElementById("saveBtn");
const discardBtn        = document.getElementById("discardBtn");
const historySection    = document.getElementById("historySection");
const historyGrid       = document.getElementById("historyGrid");
const clearHistoryBtn   = document.getElementById("clearHistoryBtn");

// PDF mode
const pdfNameInput      = document.getElementById("pdfNameInput");
const pdfCaptureBtn     = document.getElementById("pdfCaptureBtn");
const pdfStatusHint     = document.getElementById("pdfStatusHint");
const pdfPreviewSection = document.getElementById("pdfPreviewSection");
const pdfPreviewImg     = document.getElementById("pdfPreviewImg");
const pdfPreviewMeta    = document.getElementById("pdfPreviewMeta");
const addToPdfBtn       = document.getElementById("addToPdfBtn");
const pdfDiscardBtn     = document.getElementById("pdfDiscardBtn");
const pdfQueueSection   = document.getElementById("pdfQueueSection");
const queueList         = document.getElementById("queueList");
const clearQueueBtn     = document.getElementById("clearQueueBtn");
const createPdfBtn      = document.getElementById("createPdfBtn");

// Toast
const toast = document.createElement("div");
toast.className = "toast";
document.body.appendChild(toast);

// ── State ─────────────────────────────────────────────────────
let currentMode   = "single";  // "single" | "pdf"
let dirHandle     = null;
let isCapturing   = false;
let pendingDataUrl = null;     // latest capture, awaiting action
let history       = [];        // [{ name, dataUrl }]
let pdfQueue      = [];        // [{ dataUrl, width, height }]

// ── Persistence: folder handle via IndexedDB ──────────────────
const DB_NAME = "ccapture";
const STORE   = "handles";

function openDB() {
  return new Promise((res, rej) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => res(req.result);
    req.onerror   = () => rej(req.error);
  });
}

async function saveHandle(handle) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put(handle, "dir");
    tx.oncomplete = () => res();
    tx.onerror    = () => rej(tx.error);
  });
}

async function loadHandle() {
  try {
    const db = await openDB();
    return new Promise((res) => {
      const tx  = db.transaction(STORE, "readonly");
      const req = tx.objectStore(STORE).get("dir");
      req.onsuccess = () => res(req.result || null);
      req.onerror   = () => res(null);
    });
  } catch { return null; }
}

// ── Startup ───────────────────────────────────────────────────
(async () => {
  const handle = await loadHandle();
  if (handle) {
    const perm = await handle.queryPermission({ mode: "readwrite" });
    if (perm === "granted") {
      setDir(handle, false);
    } else {
      dirHandle = handle;
      folderPath.textContent = handle.name;
      folderPath.classList.add("has-folder");
      enableCaptureButtons();
      setHint("Click to start");
    }
  }
  loadHistory();
})();

// ── Mode switching ────────────────────────────────────────────
modeTabs.forEach((tab) => {
  tab.addEventListener("click", () => {
    if (isCapturing) return; // don't switch mid-capture
    currentMode = tab.dataset.mode;
    modeTabs.forEach((t) => t.classList.toggle("active", t === tab));
    singleModeEl.style.display = currentMode === "single" ? "" : "none";
    pdfModeEl.style.display    = currentMode === "pdf"    ? "" : "none";
    // Hide any open preview when switching
    previewSection.style.display    = "none";
    pdfPreviewSection.style.display = "none";
    pendingDataUrl = null;
  });
});

// ── Folder chooser ────────────────────────────────────────────
chooseFolderBtn.addEventListener("click", async () => {
  try {
    const handle = await window.showDirectoryPicker({ mode: "readwrite" });
    await setDir(handle, true);
  } catch (err) {
    if (err.name !== "AbortError") showToast("Could not open folder: " + err.message, true);
  }
});

async function setDir(handle, persist) {
  dirHandle = handle;
  folderPath.textContent = handle.name;
  folderPath.classList.add("has-folder");
  enableCaptureButtons();
  setHint("Click to start");
  if (persist) await saveHandle(handle);
}

function enableCaptureButtons() {
  captureBtn.disabled    = false;
  pdfCaptureBtn.disabled = false;
}

function setHint(msg) {
  statusHint.textContent    = msg;
  pdfStatusHint.textContent = msg;
}

// ── Ensure folder permission ──────────────────────────────────
async function ensurePermission() {
  if (!dirHandle) return false;
  const perm = await dirHandle.queryPermission({ mode: "readwrite" });
  if (perm === "granted") return true;
  const newPerm = await dirHandle.requestPermission({ mode: "readwrite" });
  return newPerm === "granted";
}

// ── Generic capture trigger ───────────────────────────────────
async function startCapture(btn, hintEl) {
  if (isCapturing) return;
  if (!await ensurePermission()) {
    showToast("Folder permission denied", true);
    return;
  }
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) { showToast("No active tab found", true); return; }

  setCapturing(true, btn, hintEl);

  const resp = await chrome.runtime.sendMessage({ type: "START_CAPTURE", tabId: tab.id });
  if (!resp?.ok) {
    setCapturing(false, btn, hintEl);
    showToast("Could not start capture: " + (resp?.error || "unknown"), true);
  }
}

captureBtn.addEventListener("click",    () => startCapture(captureBtn,    statusHint));
pdfCaptureBtn.addEventListener("click", () => startCapture(pdfCaptureBtn, pdfStatusHint));

// ── Messages from background ──────────────────────────────────
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "CAPTURE_READY") {
    const btn     = currentMode === "pdf" ? pdfCaptureBtn : captureBtn;
    const hintEl  = currentMode === "pdf" ? pdfStatusHint : statusHint;
    setCapturing(false, btn, hintEl);

    if (currentMode === "pdf") showPdfPreview(msg.dataUrl);
    else                        showSinglePreview(msg.dataUrl);
  }
  if (msg.type === "CAPTURE_CANCELLED") {
    const btn    = currentMode === "pdf" ? pdfCaptureBtn : captureBtn;
    const hintEl = currentMode === "pdf" ? pdfStatusHint : statusHint;
    setCapturing(false, btn, hintEl);
    hintEl.textContent = "Capture cancelled";
    setTimeout(() => { hintEl.textContent = "Click to start"; }, 2000);
  }
  if (msg.type === "CAPTURE_ERROR") {
    const btn    = currentMode === "pdf" ? pdfCaptureBtn : captureBtn;
    const hintEl = currentMode === "pdf" ? pdfStatusHint : statusHint;
    setCapturing(false, btn, hintEl);
    showToast("Capture failed: " + msg.error, true);
  }
});

// ── Single mode: preview / save / discard ─────────────────────
function showSinglePreview(dataUrl) {
  pendingDataUrl = dataUrl;
  previewImg.src = dataUrl;
  measureImage(dataUrl, (w, h) => { previewMeta.textContent = `${w} × ${h} px`; });
  previewSection.style.display = "";
  statusHint.textContent = "Review and save the capture";
}

saveBtn.addEventListener("click", async () => {
  if (!pendingDataUrl || !dirHandle) return;
  const filename = `capture_${timestamp()}.png`;
  try {
    await writeFile(dirHandle, filename, pendingDataUrl);
    addToHistory(filename, pendingDataUrl);
    pendingDataUrl = null;
    previewSection.style.display = "none";
    statusHint.textContent = "Click to start";
    showToast(`Saved: ${filename}`);
  } catch (err) { showToast("Save failed: " + err.message, true); }
});

discardBtn.addEventListener("click", () => {
  pendingDataUrl = null;
  previewSection.style.display = "none";
  statusHint.textContent = "Click to start";
});

// ── PDF mode: preview / add to queue / discard ────────────────
function showPdfPreview(dataUrl) {
  pendingDataUrl = dataUrl;
  pdfPreviewImg.src = dataUrl;
  measureImage(dataUrl, (w, h) => {
    pdfPreviewMeta.textContent = `${w} × ${h} px`;
    // Attach dimensions for later use
    pdfPreviewImg.dataset.w = w;
    pdfPreviewImg.dataset.h = h;
  });
  pdfPreviewSection.style.display = "";
  pdfStatusHint.textContent = "Add this capture to the PDF queue";
}

addToPdfBtn.addEventListener("click", () => {
  if (!pendingDataUrl) return;
  const w = parseInt(pdfPreviewImg.dataset.w) || 0;
  const h = parseInt(pdfPreviewImg.dataset.h) || 0;
  pdfQueue.push({ dataUrl: pendingDataUrl, width: w, height: h });
  pendingDataUrl = null;
  pdfPreviewSection.style.display = "none";
  pdfStatusHint.textContent = "Click Add Capture to add more";
  renderQueue();
  showToast(`Page ${pdfQueue.length} added`);
});

pdfDiscardBtn.addEventListener("click", () => {
  pendingDataUrl = null;
  pdfPreviewSection.style.display = "none";
  pdfStatusHint.textContent = "Click to start";
});

// ── PDF queue rendering ───────────────────────────────────────
function renderQueue() {
  if (!pdfQueue.length) {
    pdfQueueSection.style.display = "none";
    return;
  }
  pdfQueueSection.style.display = "";
  queueList.innerHTML = "";

  pdfQueue.forEach((item, i) => {
    const el = document.createElement("div");
    el.className = "queue-item";

    const idx = document.createElement("div");
    idx.className = "queue-index";
    idx.textContent = i + 1;

    const thumb = document.createElement("img");
    thumb.className = "queue-thumb";
    thumb.src = item.dataUrl;
    thumb.alt = `Page ${i + 1}`;

    const info = document.createElement("div");
    info.className = "queue-info";
    const dims = document.createElement("div");
    dims.className = "queue-dims";
    dims.textContent = item.width && item.height ? `${item.width} × ${item.height}` : "";
    info.appendChild(dims);

    // Reorder controls
    const controls = document.createElement("div");
    controls.className = "queue-controls";

    const upBtn = makeIconBtn("↑", "Move up", i === 0);
    upBtn.addEventListener("click", () => { moveQueueItem(i, -1); });

    const downBtn = makeIconBtn("↓", "Move down", i === pdfQueue.length - 1);
    downBtn.addEventListener("click", () => { moveQueueItem(i, 1); });

    controls.appendChild(upBtn);
    controls.appendChild(downBtn);

    // Remove button
    const removeBtn = makeIconBtn("×", "Remove", false);
    removeBtn.classList.add("remove");
    removeBtn.addEventListener("click", () => {
      pdfQueue.splice(i, 1);
      renderQueue();
    });

    el.appendChild(idx);
    el.appendChild(thumb);
    el.appendChild(info);
    el.appendChild(controls);
    el.appendChild(removeBtn);
    queueList.appendChild(el);
  });
}

function makeIconBtn(label, title, disabled) {
  const btn = document.createElement("button");
  btn.className = "icon-btn";
  btn.textContent = label;
  btn.title = title;
  btn.disabled = disabled;
  return btn;
}

function moveQueueItem(i, dir) {
  const j = i + dir;
  if (j < 0 || j >= pdfQueue.length) return;
  [pdfQueue[i], pdfQueue[j]] = [pdfQueue[j], pdfQueue[i]];
  renderQueue();
}

clearQueueBtn.addEventListener("click", () => {
  pdfQueue = [];
  renderQueue();
});

// ── Create PDF ────────────────────────────────────────────────
createPdfBtn.addEventListener("click", async () => {
  if (!pdfQueue.length) { showToast("Queue is empty", true); return; }
  if (!dirHandle)       { showToast("No save folder selected", true); return; }

  const rawName = pdfNameInput.value.trim() || "capture";
  // Strip any .pdf suffix the user may have typed
  const baseName = rawName.replace(/\.pdf$/i, "");
  const filename = `${baseName}.pdf`;

  createPdfBtn.disabled  = true;
  createPdfBtn.textContent = "Creating…";

  try {
    const dataUrls = pdfQueue.map((item) => item.dataUrl);
    const pdfBytes = await buildPdfFromDataUrls(dataUrls);

    const blob       = new Blob([pdfBytes], { type: "application/pdf" });
    const fileHandle = await dirHandle.getFileHandle(filename, { create: true });
    const writable   = await fileHandle.createWritable();
    await writable.write(blob);
    await writable.close();

    showToast(`Saved: ${filename}`);
    pdfQueue = [];
    renderQueue();
    pdfPreviewSection.style.display = "none";
    pdfStatusHint.textContent = "PDF saved! Add more captures anytime";
  } catch (err) {
    showToast("PDF creation failed: " + err.message, true);
  } finally {
    createPdfBtn.disabled = false;
    createPdfBtn.innerHTML =
      `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
        <polyline points="14 2 14 8 20 8"/>
      </svg> Create PDF`;
  }
});

// ── Single mode history ───────────────────────────────────────
function loadHistory() {
  chrome.storage.session.get("history", ({ history: h }) => {
    if (Array.isArray(h) && h.length) { history = h; renderHistory(); }
  });
}

function addToHistory(name, dataUrl) {
  history.unshift({ name, dataUrl });
  if (history.length > 20) history.length = 20;
  chrome.storage.session.set({ history });
  renderHistory();
}

function renderHistory() {
  if (!history.length) { historySection.style.display = "none"; return; }
  historySection.style.display = "";
  historyGrid.innerHTML = "";
  history.forEach(({ name, dataUrl }) => {
    const item  = document.createElement("div");
    item.className = "history-item";
    item.title = name;
    const img   = document.createElement("img");
    img.className = "history-thumb";
    img.src = dataUrl;
    img.alt = name;
    const label = document.createElement("div");
    label.className = "history-name";
    label.textContent = name;
    item.appendChild(img);
    item.appendChild(label);
    item.addEventListener("click", () => showSinglePreview(dataUrl));
    historyGrid.appendChild(item);
  });
}

clearHistoryBtn.addEventListener("click", () => {
  history = [];
  chrome.storage.session.remove("history");
  renderHistory();
});

// ── Helpers ───────────────────────────────────────────────────
async function writeFile(dir, name, dataUrl) {
  const base64 = dataUrl.split(",")[1];
  const bytes  = Uint8Array.from(atob(base64), (c) => c.charCodeAt(0));
  const blob   = new Blob([bytes], { type: "image/png" });
  const fh     = await dir.getFileHandle(name, { create: true });
  const wrt    = await fh.createWritable();
  await wrt.write(blob);
  await wrt.close();
}

function measureImage(dataUrl, cb) {
  const img = new Image();
  img.onload = () => cb(img.naturalWidth, img.naturalHeight);
  img.src = dataUrl;
}

function setCapturing(active, btn, hintEl) {
  isCapturing = active;
  // The active capture button
  btn.disabled = active;
  btn.classList.toggle("capturing", active);
  // Keep the other capture button enabled as long as we're not capturing
  captureBtn.disabled    = active;
  pdfCaptureBtn.disabled = active;
  // Mode tab switching disabled while capturing
  modeTabs.forEach((t) => (t.style.pointerEvents = active ? "none" : ""));
  if (active) hintEl.textContent = "Draw a rectangle on the page…";
}

function timestamp() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}${p(d.getMonth()+1)}${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}

let toastTimer = null;
function showToast(msg, isError = false) {
  toast.textContent = msg;
  toast.style.background = isError ? "#b00020" : "#1e7e34";
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2800);
}

// ── Keyboard shortcuts ────────────────────────────────────────
// Ctrl+Shift+E  Capture    Ctrl+Shift+S  Save
// Ctrl+Shift+F  Add to PDF queue    Ctrl+Shift+X  Discard
// All four registered as chrome.commands (browser-level, no focus issues).
// Ctrl+Shift avoids all Chrome native shortcuts (Ctrl-only E/D/Q conflict
// with address bar, bookmark, and quit on Linux).

function handleShortcut(key) {
  switch (key) {
    case "e": {                              // Ctrl+Shift+E — Capture
      const btn = currentMode === "pdf" ? pdfCaptureBtn : captureBtn;
      if (!btn.disabled) btn.click();
      break;
    }
    case "s":                               // Ctrl+Shift+S — Save
      if (currentMode === "single" && previewSection.style.display !== "none") {
        if (!saveBtn.disabled) saveBtn.click();
      }
      break;
    case "f":                               // Ctrl+Shift+F — Add to PDF queue
      if (currentMode === "pdf" && pdfPreviewSection.style.display !== "none") {
        if (!addToPdfBtn.disabled) addToPdfBtn.click();
      }
      break;
    case "x":                               // Ctrl+Shift+X — Discard
      if (currentMode === "single" && previewSection.style.display !== "none") {
        discardBtn.click();
      } else if (currentMode === "pdf" && pdfPreviewSection.style.display !== "none") {
        pdfDiscardBtn.click();
      }
      break;
  }
}

// Primary: background receives chrome.commands.onCommand → writes to session
// storage → onChanged fires here regardless of which window has focus.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "session" && changes.__ccapture_shortcut) {
    handleShortcut(changes.__ccapture_shortcut.newValue.key);
  }
});

// Backup: direct keydown when the panel itself has focus (no storage round-trip).
document.addEventListener("keydown", (e) => {
  if (!e.ctrlKey || !e.shiftKey || e.altKey || e.metaKey) return;
  const key = e.key.toLowerCase();
  if (new Set(["e", "s", "f", "x"]).has(key)) {
    e.preventDefault();
    handleShortcut(key);
  }
});
